import React, { useState, useEffect } from 'react';
import { 
  Plus, Edit2, Trash2, BookOpen, RotateCcw, 
  CheckCircle, XCircle, Search, ArrowLeft, ArrowRight, 
  BarChart2, Clock, Layers, HelpCircle, Award, 
  ChevronRight, Shuffle, Save, FileText, Download, Upload
} from 'lucide-react';

// --- SEED DATA ---
const INITIAL_DECKS = [
  {
    id: 'subj-1',
    subject: 'Computer Science',
    description: 'Core concepts of data structures, algorithms, and web dev.',
    lessons: [
      {
        id: 'les-1',
        title: 'Data Structures 101',
        cards: [
          { id: 'c-1', question: 'What data structure follows First-In, First-Out (FIFO)?', answer: 'Queue' },
          { id: 'c-2', question: 'What data structure operates on Last-In, First-Out (LIFO)?', answer: 'Stack' },
          { id: 'c-3', question: 'Which data structure consists of nodes with pointers to the next node?', answer: 'Linked List' },
          { id: 'c-4', question: 'What key-value store provides O(1) average lookup time?', answer: 'Hash Table' },
          { id: 'c-5', question: 'What tree structure guarantees logarithmic search time?', answer: 'Binary Search Tree' }
        ]
      },
      {
        id: 'les-2',
        title: 'Web Development Basics',
        cards: [
          { id: 'c-6', question: 'What HTML tag is used to create a hyperlink?', answer: '<a>' },
          { id: 'c-7', question: 'What CSS framework uses utility classes exclusively?', answer: 'Tailwind CSS' },
          { id: 'c-8', question: 'Which JavaScript hook handles state in functional components?', answer: 'useState' }
        ]
      }
    ]
  },
  {
    id: 'subj-2',
    subject: 'Biology',
    description: 'Cell structure, genetics, and ecology.',
    lessons: [
      {
        id: 'les-3',
        title: 'Cellular Biology',
        cards: [
          { id: 'c-9', question: 'What organelle is known as the powerhouse of the cell?', answer: 'Mitochondria' },
          { id: 'c-10', question: 'What process do plants use to convert light into chemical energy?', answer: 'Photosynthesis' },
          { id: 'c-11', question: 'What molecule carries genetic instructions in all living things?', answer: 'DNA' }
        ]
      }
    ]
  }
];

export default function App() {
  const [decks, setDecks] = useState(() => {
    const saved = localStorage.getItem('quizwiz_decks');
    return saved ? JSON.parse(saved) : INITIAL_DECKS;
  });

  const [quizHistory, setQuizHistory] = useState(() => {
    const saved = localStorage.getItem('quizwiz_history');
    return saved ? JSON.parse(saved) : [];
  });

  // Navigation State
  const [currentView, setCurrentView] = useState('DASHBOARD'); // DASHBOARD, SUBJECT_VIEW, STUDY_MODE, QUIZ_MODE, SUMMARY_MODE
  const [selectedSubjectId, setSelectedSubjectId] = useState(null);
  const [selectedLessonId, setSelectedLessonId] = useState(null);

  // Filters & Search
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState('ALL');

  // Modals
  const [isSubjectModalOpen, setIsSubjectModalOpen] = useState(false);
  const [isLessonModalOpen, setIsLessonModalOpen] = useState(false);
  const [editingSubject, setEditingSubject] = useState(null);
  const [editingLesson, setEditingLesson] = useState(null);

  // Study & Quiz State
  const [activeCards, setActiveCards] = useState([]);
  const [cardIndex, setCardIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [cardStatuses, setCardStatuses] = useState({}); // { cardId: 'mastered' | 'hard' }
  const [userTypedAnswer, setUserTypedAnswer] = useState('');
  const [quizResults, setQuizResults] = useState([]); // [{ question, correctAnswer, userTyped, isCorrect }]
  const [startTime, setStartTime] = useState(null);
  const [elapsedTime, setElapsedTime] = useState('0:00');

  // Save to localStorage
  useEffect(() => {
    localStorage.setItem('quizwiz_decks', JSON.stringify(decks));
  }, [decks]);

  useEffect(() => {
    localStorage.setItem('quizwiz_history', JSON.stringify(quizHistory));
  }, [quizHistory]);

  // Overall Mastery Calculator
  const calculateOverallMastery = () => {
    let totalCards = 0;
    let masteredCount = 0;
    decks.forEach(subject => {
      subject.lessons.forEach(lesson => {
        lesson.cards.forEach(card => {
          totalCards++;
          if (cardStatuses[card.id] === 'mastered') masteredCount++;
        });
      });
    });
    if (totalCards === 0) return 0;
    return Math.round((masteredCount / totalCards) * 100);
  };

  const calculateLessonMastery = (lesson) => {
    if (!lesson.cards || lesson.cards.length === 0) return 0;
    let mastered = 0;
    lesson.cards.forEach(card => {
      if (cardStatuses[card.id] === 'mastered') mastered++;
    });
    return Math.round((mastered / lesson.cards.length) * 100);
  };

  const calculateSubjectMastery = (subject) => {
    let totalCards = 0;
    let mastered = 0;
    subject.lessons.forEach(lesson => {
      lesson.cards.forEach(card => {
        totalCards++;
        if (cardStatuses[card.id] === 'mastered') mastered++;
      });
    });
    if (totalCards === 0) return 0;
    return Math.round((mastered / totalCards) * 100);
  };

  // Start Study (Flashcards)
  const handleStartStudy = (lesson) => {
    if (!lesson.cards || lesson.cards.length === 0) {
      alert("This lesson has no cards yet! Add cards first.");
      return;
    }
    setSelectedLessonId(lesson.id);
    setActiveCards(lesson.cards);
    setCardIndex(0);
    setIsFlipped(false);
    setStartTime(Date.now());
    setCurrentView('STUDY_MODE');
  };

  // Start Quiz (Identification)
  const handleStartQuiz = (lesson) => {
    if (!lesson.cards || lesson.cards.length === 0) {
      alert("This lesson has no cards to quiz!");
      return;
    }
    setSelectedLessonId(lesson.id);
    const shuffled = [...lesson.cards].sort(() => Math.random() - 0.5);
    setActiveCards(shuffled);
    setCardIndex(0);
    setUserTypedAnswer('');
    setQuizResults([]);
    setStartTime(Date.now());
    setCurrentView('QUIZ_MODE');
  };

  // Handle Identification Submit
  const handleQuizAnswerSubmit = (e) => {
    e.preventDefault();
    const currentCard = activeCards[cardIndex];
    const isCorrect = userTypedAnswer.trim().toLowerCase() === currentCard.answer.trim().toLowerCase();

    const newResult = {
      cardId: currentCard.id,
      question: currentCard.question,
      correctAnswer: currentCard.answer,
      userTyped: userTypedAnswer,
      isCorrect
    };

    const updatedResults = [...quizResults, newResult];
    setQuizResults(updatedResults);

    setCardStatuses(prev => ({
      ...prev,
      [currentCard.id]: isCorrect ? 'mastered' : 'hard'
    }));

    setUserTypedAnswer('');

    if (cardIndex + 1 < activeCards.length) {
      setCardIndex(prev => prev + 1);
    } else {
      const durationSeconds = Math.floor((Date.now() - startTime) / 1000);
      const mins = Math.floor(durationSeconds / 60);
      const secs = durationSeconds % 60;
      const formattedTime = `${mins}:${secs < 10 ? '0' : ''}${secs}`;
      setElapsedTime(formattedTime);

      const totalCorrect = updatedResults.filter(r => r.isCorrect).length;
      const historyEntry = {
        id: Date.now(),
        lessonId: selectedLessonId,
        subjectId: selectedSubjectId,
        score: totalCorrect,
        total: activeCards.length,
        accuracy: Math.round((totalCorrect / activeCards.length) * 100),
        duration: formattedTime,
        date: new Date().toLocaleDateString()
      };
      setQuizHistory(prev => [historyEntry, ...prev]);

      setCurrentView('SUMMARY_MODE');
    }
  };

  // Mark Flashcard
  const handleMarkStatus = (status) => {
    const currentCard = activeCards[cardIndex];
    setCardStatuses(prev => ({ ...prev, [currentCard.id]: status }));

    if (cardIndex + 1 < activeCards.length) {
      setCardIndex(prev => prev + 1);
      setIsFlipped(false);
    } else {
      const durationSeconds = Math.floor((Date.now() - startTime) / 1000);
      const mins = Math.floor(durationSeconds / 60);
      const secs = durationSeconds % 60;
      setElapsedTime(`${mins}:${secs < 10 ? '0' : ''}${secs}`);
      
      const generatedResults = activeCards.map(c => ({
        cardId: c.id,
        question: c.question,
        correctAnswer: c.answer,
        userTyped: (cardStatuses[c.id] || status) === 'mastered' ? c.answer : 'Marked Hard',
        isCorrect: (cardStatuses[c.id] || status) === 'mastered'
      }));
      setQuizResults(generatedResults);
      setCurrentView('SUMMARY_MODE');
    }
  };

  // Save Subject Modal
  const handleSaveSubject = (title, description) => {
    if (editingSubject) {
      setDecks(decks.map(s => s.id === editingSubject.id ? { ...s, subject: title, description } : s));
    } else {
      const newSubject = {
        id: `subj-${Date.now()}`,
        subject: title,
        description,
        lessons: []
      };
      setDecks([...decks, newSubject]);
    }
    setIsSubjectModalOpen(false);
    setEditingSubject(null);
  };

  // Save Lesson Modal
  const handleSaveLesson = (title, cards) => {
    setDecks(decks.map(subject => {
      if (subject.id === selectedSubjectId) {
        if (editingLesson) {
          const updatedLessons = subject.lessons.map(l => l.id === editingLesson.id ? { ...l, title, cards } : l);
          return { ...subject, lessons: updatedLessons };
        } else {
          const newLesson = {
            id: `les-${Date.now()}`,
            title,
            cards
          };
          return { ...subject, lessons: [...subject.lessons, newLesson] };
        }
      }
      return subject;
    }));
    setIsLessonModalOpen(false);
    setEditingLesson(null);
  };

  // Export & Import Data
  const handleExportData = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify({ decks, quizHistory }));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `quizwiz_backup_${new Date().toISOString().slice(0,10)}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleImportData = (e) => {
    const fileReader = new FileReader();
    fileReader.readAsText(e.target.files[0], "UTF-8");
    fileReader.onload = (e) => {
      try {
        const parsed = JSON.parse(e.target.result);
        if (parsed.decks) setDecks(parsed.decks);
        if (parsed.quizHistory) setQuizHistory(parsed.quizHistory);
        alert("Data imported successfully!");
      } catch (err) {
        alert("Invalid JSON file format.");
      }
    };
  };

  const activeSubject = decks.find(s => s.id === selectedSubjectId);
  const activeLesson = activeSubject?.lessons.find(l => l.id === selectedLessonId);

  const filteredDecks = decks.filter(d => {
    const matchesSearch = d.subject.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          d.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategoryFilter === 'ALL' || d.subject === selectedCategoryFilter;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 font-sans flex flex-col">
      {/* HEADER NAVBAR */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-30 px-6 py-4 flex items-center justify-between shadow-sm">
        <div className="flex items-center space-x-3 cursor-pointer" onClick={() => setCurrentView('DASHBOARD')}>
          <div className="bg-indigo-600 text-white p-2 rounded-lg shadow">
            <BookOpen className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight text-slate-900">QuizWiz</h1>
            <p className="text-xs text-slate-500 font-medium">Interactive Study Engine</p>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          <label className="cursor-pointer bg-slate-100 hover:bg-slate-200 text-slate-700 px-3 py-2 rounded-lg text-sm font-medium flex items-center space-x-2 transition">
            <Upload className="w-4 h-4" />
            <span>Import JSON</span>
            <input type="file" accept=".json" onChange={handleImportData} className="hidden" />
          </label>
          <button 
            onClick={handleExportData}
            className="bg-slate-100 hover:bg-slate-200 text-slate-700 px-3 py-2 rounded-lg text-sm font-medium flex items-center space-x-2 transition"
          >
            <Download className="w-4 h-4" />
            <span>Export Data</span>
          </button>
        </div>
      </header>

      {/* MAIN CONTENT AREA */}
      <main className="flex-1 max-w-6xl w-full mx-auto p-6">
        
        {/* ================= DASHBOARD VIEW ================= */}
        {currentView === 'DASHBOARD' && (
          <div className="space-y-8">
            <div className="bg-gradient-to-r from-indigo-600 to-purple-600 rounded-2xl p-8 text-white shadow-xl flex flex-col md:flex-row justify-between items-start md:items-center">
              <div>
                <h2 className="text-3xl font-extrabold tracking-tight mb-2">Lorem Ipsum dolor sit amet</h2>
                <p className="text-indigo-100 text-sm max-w-lg">
                  Organize your subjects, create custom interactive flashcards, and test your knowledge.
                </p>
                <div className="mt-6 flex items-center space-x-6">
                  <div>
                    <span className="text-xs uppercase tracking-wider text-indigo-200 font-semibold block">Overall Mastery</span>
                    <span className="text-2xl font-bold">{calculateOverallMastery()}%</span>
                  </div>
                  <div className="h-8 w-px bg-indigo-400/40"></div>
                  <div>
                    <span className="text-xs uppercase tracking-wider text-indigo-200 font-semibold block">Total Subjects</span>
                    <span className="text-2xl font-bold">{decks.length}</span>
                  </div>
                </div>
              </div>
              <button 
                onClick={() => { setEditingSubject(null); setIsSubjectModalOpen(true); }}
                className="mt-6 md:mt-0 bg-white text-indigo-600 hover:bg-indigo-50 font-bold px-5 py-3 rounded-xl shadow-md transition flex items-center space-x-2"
              >
                <Plus className="w-5 h-5" />
                <span>Add Subject</span>
              </button>
            </div>

            <div>
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
                <h3 className="text-2xl font-bold text-slate-900">My Decks</h3>

                <div className="flex items-center space-x-3">
                  <div className="relative">
                    <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input 
                      type="text" 
                      placeholder="Search decks..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-9 pr-4 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 w-48 md:w-64"
                    />
                  </div>

                  <div className="flex items-center space-x-2 border border-slate-300 bg-white rounded-lg px-3 py-2 text-sm">
                    <span className="text-slate-500 text-xs font-semibold uppercase">Filter:</span>
                    <select 
                      value={selectedCategoryFilter}
                      onChange={(e) => setSelectedCategoryFilter(e.target.value)}
                      className="bg-transparent text-slate-700 font-medium focus:outline-none cursor-pointer"
                    >
                      <option value="ALL">All Subjects</option>
                      {decks.map(d => (
                        <option key={d.id} value={d.subject}>{d.subject}</option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {filteredDecks.map((deck, index) => {
                  const mastery = calculateSubjectMastery(deck);
                  return (
                    <div 
                      key={deck.id}
                      onClick={() => { setSelectedSubjectId(deck.id); setCurrentView('SUBJECT_VIEW'); }}
                      className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm hover:shadow-md transition cursor-pointer flex flex-col justify-between group"
                    >
                      <div>
                        <div className="flex justify-between items-start mb-3">
                          <span className="text-xs font-bold text-indigo-600 bg-indigo-50 px-2.5 py-1 rounded-full uppercase tracking-wider">
                            Deck 0{index + 1}
                          </span>
                          <button 
                            onClick={(e) => {
                              e.stopPropagation();
                              if (confirm(`Delete subject "${deck.subject}"?`)) {
                                setDecks(decks.filter(s => s.id !== deck.id));
                              }
                            }}
                            className="text-slate-400 hover:text-red-500 opacity-0 group-hover:opacity-100 transition p-1"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                        <h4 className="text-xl font-bold text-slate-900 group-hover:text-indigo-600 transition">{deck.subject}</h4>
                        <p className="text-xs text-slate-500 mt-1 line-clamp-2">{deck.description}</p>
                      </div>

                      <div className="mt-8 pt-4 border-t border-slate-100">
                        <div className="flex justify-between text-xs font-semibold text-slate-500 mb-1.5">
                          <span>Mastery Level</span>
                          <span className="text-slate-900">{mastery}%</span>
                        </div>
                        <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                          <div 
                            className="bg-indigo-600 h-full rounded-full transition-all duration-300"
                            style={{ width: `${mastery}%` }}
                          ></div>
                        </div>
                      </div>
                    </div>
                  );
                })}

                {filteredDecks.length === 0 && (
                  <div className="col-span-full text-center py-12 bg-white rounded-xl border border-dashed border-slate-300">
                    <Layers className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                    <p className="text-slate-500 font-medium">No subject decks found.</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* ================= SUBJECT VIEW (LESSONS LIST) ================= */}
        {currentView === 'SUBJECT_VIEW' && activeSubject && (
          <div className="space-y-6">
            <button 
              onClick={() => setCurrentView('DASHBOARD')}
              className="inline-flex items-center space-x-2 text-sm font-semibold text-indigo-600 hover:text-indigo-800"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back to Decks</span>
            </button>

            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-200 pb-6">
              <div>
                <h2 className="text-3xl font-extrabold text-slate-900">{activeSubject.subject}</h2>
                <p className="text-sm text-slate-500 mt-1">Click to start lessons and take quiz</p>
              </div>

              <div className="flex items-center space-x-3">
                <button 
                  onClick={() => {
                    setEditingSubject(activeSubject);
                    setIsSubjectModalOpen(true);
                  }}
                  className="px-4 py-2 border border-slate-300 text-slate-700 hover:bg-slate-50 rounded-lg text-sm font-semibold transition"
                >
                  Edit Subject
                </button>
                <button 
                  onClick={() => { setEditingLesson(null); setIsLessonModalOpen(true); }}
                  className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold px-4 py-2 rounded-lg text-sm shadow transition flex items-center space-x-2"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add Lesson</span>
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              {activeSubject.lessons.map((lesson, idx) => {
                const lessonMastery = calculateLessonMastery(lesson);
                return (
                  <div key={lesson.id} className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm hover:shadow-md transition flex flex-col justify-between group">
                    <div>
                      <div className="flex justify-between items-start mb-4">
                        <button 
                          onClick={() => { setEditingLesson(lesson); setIsLessonModalOpen(true); }}
                          className="px-3 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded text-xs font-semibold transition"
                        >
                          Edit
                        </button>
                        <span className="text-xs font-semibold text-slate-400">{lesson.cards.length} Cards</span>
                      </div>

                      <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">
                        Lesson 0{idx + 1}
                      </span>
                      <h4 className="text-lg font-bold text-slate-900 mb-4">{lesson.title}</h4>
                    </div>

                    <div className="space-y-4">
                      <div className="grid grid-cols-2 gap-2">
                        <button 
                          onClick={() => handleStartStudy(lesson)}
                          className="w-full bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold py-2 rounded-lg transition"
                        >
                          Study
                        </button>
                        <button 
                          onClick={() => handleStartQuiz(lesson)}
                          className="w-full bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold py-2 rounded-lg transition"
                        >
                          Quiz
                        </button>
                      </div>

                      <div>
                        <div className="flex justify-between text-[11px] font-semibold text-slate-400 mb-1">
                          <span>Mastery Level</span>
                          <span>{lessonMastery}%</span>
                        </div>
                        <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
                          <div 
                            className="bg-indigo-600 h-full rounded-full transition-all duration-300"
                            style={{ width: `${lessonMastery}%` }}
                          ></div>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}

              {activeSubject.lessons.length === 0 && (
                <div className="col-span-full text-center py-12 bg-white rounded-xl border border-dashed border-slate-300">
                  <BookOpen className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                  <p className="text-slate-500 font-medium">No lessons added to this subject yet.</p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* ================= FLASHCARD STUDY MODE ================= */}
        {currentView === 'STUDY_MODE' && activeLesson && (
          <div className="max-w-3xl mx-auto space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-2xl font-bold text-slate-900">{activeLesson.title}</h3>
                <p className="text-xs text-slate-500 font-medium">Click card to reveal answer</p>
              </div>

              <div className="text-right">
                <span className="text-2xl font-bold text-slate-900">{cardIndex + 1}/{activeCards.length}</span>
                <div className="w-32 bg-slate-200 rounded-full h-2 mt-1">
                  <div 
                    className="bg-indigo-600 h-full rounded-full transition-all duration-300"
                    style={{ width: `${((cardIndex + 1) / activeCards.length) * 100}%` }}
                  ></div>
                </div>
              </div>
            </div>

            <div 
              onClick={() => setIsFlipped(!isFlipped)}
              className="w-full h-80 bg-white border-2 border-slate-200 rounded-2xl shadow-sm hover:shadow-md transition cursor-pointer flex flex-col justify-between p-8 text-center relative select-none"
            >
              <div className="text-xs font-bold text-slate-400 uppercase tracking-widest">
                {isFlipped ? 'Answer' : `Question ${cardIndex + 1}`}
              </div>

              <div className="my-auto px-4">
                <p className="text-2xl font-medium text-slate-800 leading-relaxed">
                  {isFlipped ? activeCards[cardIndex]?.answer : activeCards[cardIndex]?.question}
                </p>
              </div>

              {isFlipped ? (
                <div className="flex justify-center space-x-4 pt-4" onClick={(e) => e.stopPropagation()}>
                  <button 
                    onClick={() => handleMarkStatus('hard')}
                    className="px-6 py-2 border border-slate-300 text-slate-700 hover:bg-red-50 hover:border-red-200 hover:text-red-600 rounded-lg text-sm font-bold transition"
                  >
                    Hard
                  </button>
                  <button 
                    onClick={() => handleMarkStatus('mastered')}
                    className="px-6 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm font-bold shadow transition"
                  >
                    Mastered
                  </button>
                </div>
              ) : (
                <div className="text-xs text-slate-400 font-medium">Click anywhere to flip</div>
              )}
            </div>

            <div className="flex justify-between items-center pt-2">
              <button 
                disabled={cardIndex === 0}
                onClick={() => { setCardIndex(prev => prev - 1); setIsFlipped(false); }}
                className="px-4 py-2 border border-slate-300 rounded-lg text-sm font-semibold text-slate-700 disabled:opacity-40 hover:bg-slate-50 transition flex items-center space-x-2"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Prev</span>
              </button>

              <button 
                onClick={() => setCurrentView('SUBJECT_VIEW')}
                className="text-xs text-slate-500 font-semibold hover:text-slate-800"
              >
                Exit Session
              </button>

              <button 
                disabled={cardIndex + 1 === activeCards.length}
                onClick={() => { setCardIndex(prev => prev + 1); setIsFlipped(false); }}
                className="px-4 py-2 border border-slate-300 rounded-lg text-sm font-semibold text-slate-700 disabled:opacity-40 hover:bg-slate-50 transition flex items-center space-x-2"
              >
                <span>Next</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* ================= IDENTIFICATION QUIZ MODE ================= */}
        {currentView === 'QUIZ_MODE' && activeLesson && (
          <div className="max-w-3xl mx-auto space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-2xl font-bold text-slate-900">{activeLesson.title} (Quiz)</h3>
                <p className="text-xs text-slate-500 font-medium">Identification Mode: Type your answer below</p>
              </div>

              <div className="text-right">
                <span className="text-2xl font-bold text-slate-900">{cardIndex + 1}/{activeCards.length}</span>
                <div className="w-32 bg-slate-200 rounded-full h-2 mt-1">
                  <div 
                    className="bg-indigo-600 h-full rounded-full transition-all duration-300"
                    style={{ width: `${((cardIndex + 1) / activeCards.length) * 100}%` }}
                  ></div>
                </div>
              </div>
            </div>

            <div className="bg-white border border-slate-200 rounded-2xl p-8 shadow-sm space-y-6">
              <div className="text-xs font-bold text-indigo-600 uppercase tracking-wider">
                Question {cardIndex + 1}
              </div>

              <h4 className="text-xl font-bold text-slate-900 leading-snug">
                {activeCards[cardIndex]?.question}
              </h4>

              <form onSubmit={handleQuizAnswerSubmit} className="space-y-4 pt-4">
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
                    Your Answer:
                  </label>
                  <input 
                    type="text"
                    required
                    autoFocus
                    value={userTypedAnswer}
                    onChange={(e) => setUserTypedAnswer(e.target.value)}
                    placeholder="Type answer here..."
                    className="w-full border-2 border-slate-300 rounded-xl px-4 py-3 text-lg focus:outline-none focus:border-indigo-600 transition"
                  />
                </div>

                <div className="flex justify-end pt-2">
                  <button 
                    type="submit"
                    className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold px-6 py-3 rounded-xl shadow transition flex items-center space-x-2"
                  >
                    <span>Submit & Next</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* ================= SUMMARY / RESULTS VIEW ================= */}
        {currentView === 'SUMMARY_MODE' && activeLesson && (
          <div className="max-w-4xl mx-auto space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-2xl font-bold text-slate-900">{activeLesson.title}</h3>
                <p className="text-xs text-slate-500 font-medium">Completed review</p>
              </div>
              <div className="text-right">
                <span className="text-2xl font-bold text-slate-900">
                  {quizResults.filter(r => r.isCorrect).length}/{quizResults.length}
                </span>
                <div className="w-32 bg-slate-200 rounded-full h-2 mt-1">
                  <div className="bg-indigo-600 h-full rounded-full w-full"></div>
                </div>
              </div>
            </div>

            <div className="bg-white border-2 border-indigo-500 rounded-2xl shadow-md grid grid-cols-1 md:grid-cols-2 overflow-hidden">
              <div className="p-8 border-b md:border-b-0 md:border-r border-slate-200 flex flex-col items-center justify-center text-center">
                <span className="text-sm font-semibold text-slate-500 mb-2">Total Score:</span>
                <div className="text-6xl font-extrabold text-slate-900 mb-6">
                  {quizResults.filter(r => r.isCorrect).length}/{quizResults.length}
                </div>

                <div className="flex space-x-12">
                  <div>
                    <span className="text-xs text-slate-400 uppercase font-semibold block">Duration:</span>
                    <span className="text-lg font-bold text-slate-800">{elapsedTime}</span>
                  </div>
                  <div>
                    <span className="text-xs text-slate-400 uppercase font-semibold block">Accuracy:</span>
                    <span className="text-lg font-bold text-slate-800">
                      {Math.round((quizResults.filter(r => r.isCorrect).length / quizResults.length) * 100)}%
                    </span>
                  </div>
                </div>
              </div>

              <div className="p-8 space-y-6 flex flex-col justify-between bg-slate-50/50">
                <div>
                  <div className="flex justify-between items-center mb-4">
                    <h4 className="text-lg font-bold text-slate-900">Question Breakdown</h4>
                    <span className="text-xs font-semibold text-slate-400 uppercase">Marks</span>
                  </div>

                  <div className="space-y-3 max-h-56 overflow-y-auto pr-2">
                    {quizResults.map((res, idx) => (
                      <div key={idx} className="flex items-center justify-between text-sm py-1 border-b border-slate-200/60 last:border-0">
                        <div className="truncate max-w-[200px]">
                          <span className="font-bold text-slate-700 mr-2">Q{idx + 1}</span>
                          <span className="text-slate-500 text-xs truncate">{res.question}</span>
                        </div>
                        <div>
                          {res.isCorrect ? (
                            <CheckCircle className="w-5 h-5 text-emerald-500" />
                          ) : (
                            <XCircle className="w-5 h-5 text-rose-500" />
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="space-y-2 pt-4">
                  <button 
                    onClick={() => handleStartQuiz(activeLesson)}
                    className="w-full py-2.5 border border-slate-300 hover:bg-slate-100 rounded-lg text-sm font-bold text-slate-800 transition"
                  >
                    Retake Quiz
                  </button>
                  <button 
                    onClick={() => setCurrentView('DASHBOARD')}
                    className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm font-bold transition shadow"
                  >
                    Back to Dashboard
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

      </main>

      {/* ================= SUBJECT MODAL ================= */}
      {isSubjectModalOpen && (
        <SubjectModal 
          subject={editingSubject}
          onClose={() => setIsSubjectModalOpen(false)}
          onSave={handleSaveSubject}
        />
      )}

      {/* ================= LESSON MODAL ================= */}
      {isLessonModalOpen && (
        <LessonModal 
          lesson={editingLesson}
          onClose={() => setIsLessonModalOpen(false)}
          onSave={handleSaveLesson}
        />
      )}
    </div>
  );
}

// --- SUBJECT MODAL COMPONENT ---
function SubjectModal({ subject, onClose, onSave }) {
  const [title, setTitle] = useState(subject ? subject.subject : '');
  const [description, setDescription] = useState(subject ? subject.description : '');

  return (
    <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white border border-slate-200 rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-6">
        <div>
          <h3 className="text-2xl font-bold text-slate-900">{subject ? 'Edit Subject' : 'Create Subject'}</h3>
          <p className="text-xs text-slate-500 mt-1">Create or modify a study deck subject</p>
        </div>

        <form onSubmit={(e) => { e.preventDefault(); onSave(title, description); }} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-600 uppercase mb-2">Subject Title:</label>
            <input 
              type="text" 
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Computer Science"
              className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-600 uppercase mb-2">Description:</label>
            <textarea 
              rows="3"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Brief description of the subject..."
              className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div className="flex justify-end space-x-3 pt-4 border-t border-slate-100">
            <button 
              type="button" 
              onClick={onClose}
              className="px-4 py-2 border border-slate-300 text-slate-700 hover:bg-slate-50 rounded-lg text-sm font-semibold"
            >
              Cancel
            </button>
            <button 
              type="submit"
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm font-bold shadow"
            >
              Save
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

// --- LESSON MODAL COMPONENT ---
function LessonModal({ lesson, onClose, onSave }) {
  const [title, setTitle] = useState(lesson ? lesson.title : '');
  const [cards, setCards] = useState(lesson ? lesson.cards : [{ id: 'c-1', question: '', answer: '' }]);

  const handleAddCardRow = () => {
    setCards([...cards, { id: `c-${Date.now()}`, question: '', answer: '' }]);
  };

  const handleCardChange = (id, field, value) => {
    setCards(cards.map(c => c.id === id ? { ...c, [field]: value } : c));
  };

  const handleRemoveCard = (id) => {
    if (cards.length === 1) return;
    setCards(cards.filter(c => c.id !== id));
  };

  return (
    <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white border border-slate-200 rounded-2xl max-w-xl w-full p-6 shadow-2xl space-y-6 max-h-[90vh] flex flex-col">
        <div>
          <h3 className="text-2xl font-bold text-slate-900">{lesson ? 'Edit Lesson' : 'Add New Lesson'}</h3>
          <p className="text-xs text-slate-500 mt-1">Edit title and manage flashcard question-answer pairs.</p>
        </div>

        <div className="flex-1 overflow-y-auto space-y-4 pr-1">
          <div>
            <label className="block text-xs font-bold text-slate-600 uppercase mb-2">Lesson Title:</label>
            <input 
              type="text" 
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Data Structures 101"
              className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div className="pt-2">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block mb-3">
              Cards ({cards.length})
            </span>

            <div className="space-y-4">
              {cards.map((card, idx) => (
                <div key={card.id} className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-3 relative group">
                  <div className="flex justify-between items-center text-xs text-slate-400 font-bold">
                    <span>Card #{idx + 1}</span>
                    {cards.length > 1 && (
                      <button 
                        type="button" 
                        onClick={() => handleRemoveCard(card.id)}
                        className="text-slate-400 hover:text-red-500 transition"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-500 uppercase mb-1">Question:</label>
                    <input 
                      type="text"
                      required
                      value={card.question}
                      onChange={(e) => handleCardChange(card.id, 'question', e.target.value)}
                      placeholder="Enter question..."
                      className="w-full border border-slate-300 rounded-lg px-3 py-1.5 text-sm focus:outline-none focus:ring-1 focus:ring-indigo-500"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-500 uppercase mb-1">Answer:</label>
                    <input 
                      type="text"
                      required
                      value={card.answer}
                      onChange={(e) => handleCardChange(card.id, 'answer', e.target.value)}
                      placeholder="Enter correct answer..."
                      className="w-full border border-slate-300 rounded-lg px-3 py-1.5 text-sm focus:outline-none focus:ring-1 focus:ring-indigo-500"
                    />
                  </div>
                </div>
              ))}
            </div>

            <button 
              type="button"
              onClick={handleAddCardRow}
              className="mt-4 w-full py-2 border border-dashed border-indigo-400 text-indigo-600 hover:bg-indigo-50 rounded-xl text-xs font-bold transition flex items-center justify-center space-x-1"
            >
              <Plus className="w-4 h-4" />
              <span>Add Card</span>
            </button>
          </div>
        </div>

        <div className="flex justify-end space-x-3 pt-4 border-t border-slate-100">
          <button 
            type="button" 
            onClick={onClose}
            className="px-4 py-2 border border-slate-300 text-slate-700 hover:bg-slate-50 rounded-lg text-sm font-semibold"
          >
            Cancel
          </button>
          <button 
            type="button"
            onClick={() => onSave(title, cards)}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm font-bold shadow"
          >
            Save
          </button>
        </div>
      </div>
    </div>
  );
}
